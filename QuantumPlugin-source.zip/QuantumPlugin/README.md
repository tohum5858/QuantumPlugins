# Quantum — Paper 1.21.4

Quantum is a Paper plugin targeting Minecraft Java 1.21.4 and Java 21.

## Included features
- `/tpa <player>` sends a teleport request with clickable `[Kabul]` and `[Reddet]` buttons.
- `/kabul` and `/reddet` accept/reject the pending TPA request. Requests expire after 60 seconds.
- Every 60 seconds: removes dropped item entities in loaded worlds.
- Every 120 seconds: removes dropped items and non-player living entities in chunks where players are standing.
- `/clearlag`: manually runs the full cleanup. Requires `quantum.admin` (operators by default).
- Blocks player portal travel when the destination is in the Nether above Y=127.
- `/dupe`: duplicates the item stack in the player's main hand. Requires `quantum.dupe` (operators by default). This is an explicit command-based duplication feature, not a vanilla donkey/piston exploit.
- `/quantum`: shows plugin version and command list.

## Important notes
- The 120-second mob cleanup removes passive animals too (for example cows, sheep, and villagers) if they are in a player's current chunk. Test on a copy of your world before enabling this on a live server.
- Donkey duplication and piston duplication glitches depend on the exact server software/version and are not universally enabled by a plugin. This project does not claim to enable those vanilla glitches; it provides the permission-controlled `/dupe` command instead.
- “Pass system” was not specific enough to implement safely. It could mean a password/login system or a battle-pass/rewards system; those are different features.
- No compiled JAR is included in this source ZIP. Use the included GitHub Actions workflow to build it in the cloud, or compile with Maven and Java 21.

## Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP (the files inside the folder, not the ZIP itself).
2. Open the repository's **Actions** tab and enable Actions if asked.
3. Select the **Build Quantum plugin** workflow and click **Run workflow**.
4. Open the completed run and download the `Quantum-jar` artifact.
5. Extract `Quantum.jar`, upload it into the server's `plugins` folder, and restart the Paper server.

## Requirements
- Paper 1.21.4
- Java 21
