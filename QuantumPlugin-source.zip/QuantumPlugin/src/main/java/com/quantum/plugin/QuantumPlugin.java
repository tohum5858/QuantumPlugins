package com.quantum.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class QuantumPlugin extends JavaPlugin implements Listener {
    private final Map<UUID, UUID> incomingRequests = new HashMap<>();
    private final Map<UUID, Long> requestExpiry = new HashMap<>();
    private static final long REQUEST_TTL_MS = 60_000L;

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> cleanup(false, true), 20L * 60, 20L * 60);
        Bukkit.getScheduler().runTaskTimer(this, () -> cleanup(true, true), 20L * 120, 20L * 120);
        getLogger().info("Quantum enabled.");
    }

    @Override
    public void onDisable() {
        incomingRequests.clear();
        requestExpiry.clear();
    }

    private int[] cleanup(boolean removeMobsInPlayerChunks, boolean announce) {
        int removedItems = 0;
        int removedMobs = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity instanceof Item) {
                    entity.remove();
                    removedItems++;
                }
            }
        }
        if (removeMobsInPlayerChunks) {
            // Use a set of chunks so players standing in the same chunk don't cause duplicate scans.
            java.util.Set<Chunk> chunks = new java.util.HashSet<>();
            for (Player player : Bukkit.getOnlinePlayers()) chunks.add(player.getLocation().getChunk());
            for (Chunk chunk : chunks) {
                for (Entity entity : chunk.getEntities()) {
                    if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                        entity.remove();
                        removedMobs++;
                    }
                }
            }
        }
        if (announce) {
            Bukkit.broadcast(Component.text("Quantum » Temizlik: " + removedItems + " yerdeki eşya"
                    + (removeMobsInPlayerChunks ? ", " + removedMobs + " mob" : "") + " silindi.", NamedTextColor.AQUA));
        }
        return new int[]{removedItems, removedMobs};
    }

    @EventHandler
    public void onPortal(PlayerPortalEvent event) {
        if (event.getTo() == null) return;
        World destination = event.getTo().getWorld();
        if (destination != null && destination.getEnvironment() == World.Environment.NETHER
                && event.getTo().getY() > 127) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text(
                    "Quantum » Nether tavanına portal ile çıkış engellendi.", NamedTextColor.RED));
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase();
        if (name.equals("quantum")) {
            sender.sendMessage(Component.text("Quantum v" + getDescription().getVersion() + " aktif.", NamedTextColor.AQUA));
            sender.sendMessage(Component.text("Komutlar: /tpa, /kabul, /reddet, /clearlag, /dupe", NamedTextColor.GRAY));
            return true;
        }
        if (name.equals("clearlag")) {
            if (!sender.hasPermission("quantum.admin")) {
                sender.sendMessage(Component.text("Bu komut için quantum.admin izni gerekiyor.", NamedTextColor.RED));
                return true;
            }
            int[] counts = cleanup(true, false);
            sender.sendMessage(Component.text("Quantum » Temizlik tamamlandı: " + counts[0]
                    + " eşya ve " + counts[1] + " mob silindi.", NamedTextColor.GREEN));
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut oyuncular içindir.");
            return true;
        }
        switch (name) {
            case "dupe" -> {
                if (!player.hasPermission("quantum.dupe")) {
                    player.sendMessage(Component.text("Bu komut için quantum.dupe izni gerekiyor.", NamedTextColor.RED));
                    return true;
                }
                ItemStack held = player.getInventory().getItemInMainHand();
                if (held.getType().isAir()) {
                    player.sendMessage(Component.text("Quantum » Önce eline çoğaltmak istediğin eşyayı al.", NamedTextColor.RED));
                    return true;
                }
                ItemStack copy = held.clone();
                Map<Integer, ItemStack> overflow = player.getInventory().addItem(copy);
                for (ItemStack extra : overflow.values()) player.getWorld().dropItemNaturally(player.getLocation(), extra);
                player.sendMessage(Component.text("Quantum » Elindeki eşya kopyalandı.", NamedTextColor.GREEN));
                return true;
            }
            case "tpa" -> {
                if (args.length != 1) {
                    player.sendMessage(Component.text("Kullanım: /tpa <oyuncu>", NamedTextColor.YELLOW));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(Component.text("Oyuncu çevrimiçi değil.", NamedTextColor.RED));
                    return true;
                }
                if (target.getUniqueId().equals(player.getUniqueId())) {
                    player.sendMessage(Component.text("Kendine TPA gönderemezsin.", NamedTextColor.RED));
                    return true;
                }
                incomingRequests.put(target.getUniqueId(), player.getUniqueId());
                requestExpiry.put(target.getUniqueId(), System.currentTimeMillis() + REQUEST_TTL_MS);
                player.sendMessage(Component.text("Quantum » TPA isteği gönderildi: " + target.getName(), NamedTextColor.GREEN));
                target.sendMessage(Component.text(player.getName() + " yanına ışınlanmak istiyor. ", NamedTextColor.AQUA)
                        .append(Component.text("[Kabul]", NamedTextColor.GREEN).clickEvent(ClickEvent.runCommand("/kabul")))
                        .append(Component.text(" "))
                        .append(Component.text("[Reddet]", NamedTextColor.RED).clickEvent(ClickEvent.runCommand("/reddet"))));
                target.sendMessage(Component.text("60 saniye içinde /kabul veya /reddet yazabilirsin.", NamedTextColor.GRAY));
                return true;
            }
            case "kabul" -> {
                UUID requesterId = incomingRequests.remove(player.getUniqueId());
                Long expiry = requestExpiry.remove(player.getUniqueId());
                if (requesterId == null || expiry == null || System.currentTimeMillis() > expiry) {
                    player.sendMessage(Component.text("Bekleyen Quantum TPA isteğin yok veya süresi doldu.", NamedTextColor.RED));
                    return true;
                }
                Player requester = Bukkit.getPlayer(requesterId);
                if (requester == null || !requester.isOnline()) {
                    player.sendMessage(Component.text("İsteği gönderen oyuncu çevrimdışı.", NamedTextColor.RED));
                    return true;
                }
                requester.teleportAsync(player.getLocation()).thenAccept(success -> {
                    if (success) {
                        requester.sendMessage(Component.text("Quantum » Işınlandın!", NamedTextColor.GREEN));
                        player.sendMessage(Component.text("Quantum » TPA isteğini kabul ettin.", NamedTextColor.GREEN));
                    } else requester.sendMessage(Component.text("Quantum » Işınlanma başarısız oldu.", NamedTextColor.RED));
                });
                return true;
            }
            case "reddet" -> {
                UUID requesterId = incomingRequests.remove(player.getUniqueId());
                requestExpiry.remove(player.getUniqueId());
                if (requesterId == null) {
                    player.sendMessage(Component.text("Bekleyen Quantum TPA isteğin yok.", NamedTextColor.RED));
                    return true;
                }
                Player requester = Bukkit.getPlayer(requesterId);
                if (requester != null) requester.sendMessage(Component.text("Quantum » TPA isteğin reddedildi.", NamedTextColor.RED));
                player.sendMessage(Component.text("Quantum » TPA isteğini reddettin.", NamedTextColor.RED));
                return true;
            }
            default -> { return false; }
        }
    }
}
